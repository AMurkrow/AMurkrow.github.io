Quake3Arena Skin
"Dcay"

Made by Cosmos in Photoshop
do not steal,cut�n�paste or copy any of these skins as your own creation
www.clanworld.dk/skinsurgeon
cosmos@post12.tele.dk
